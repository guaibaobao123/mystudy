**NOTE:**
- new version `v0.2.0` will release at [falcon-plus](https://github.com/open-falcon/falcon-plus).

# Wiki

http://open-falcon.org


# License

Licensed under the Apache License, Version 2.0: http://www.apache.org/licenses/LICENSE-2.0

Copyright 2014-2015 Xiaomi, Inc.

Copyright 2016 open-falcon.org
